package com.example.extra_pdm_lista_prg

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val Insira_Nome=findViewById<EditText>(R.id.Insira_nome)
        val Insira_Senha=findViewById<EditText>(R.id.Insira_Senha)
        val btn_Login=findViewById<Button>(R.id.btn_Login)
        val txt_Login=findViewById<TextView>(R.id.txt_Login)
        btn_Login.setOnClickListener {
            if(Insira_Nome!=null && Insira_Senha!=null){
                val estado_lgbt="Sucesso"
                txt_Login.setText(estado_lgbt)
                val tela2 = Intent(this, Tela2Activity::class.java)
                startActivity(tela2)
            }

        }
    }

}