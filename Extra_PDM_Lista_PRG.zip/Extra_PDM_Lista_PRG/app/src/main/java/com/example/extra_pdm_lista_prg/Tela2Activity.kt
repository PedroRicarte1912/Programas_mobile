package com.example.extra_pdm_lista_prg

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView


class Tela2Activity: AppCompatActivity( ){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela2)

        /*
        * Criação das variáveis que recebem os botões e textsviews
        * */
        val txt_Titulo=findViewById<TextView>(R.id.txt_Titulo)
        val btn_Bacon=findViewById<RadioButton>(R.id.btn_Bacon)
        val btn_Picles=findViewById<RadioButton>(R.id.btn_picles)
        val btn_Queijo=findViewById<RadioButton>(R.id.btn_queijo)
        val txt_quantidade=findViewById<TextView>(R.id.txt_Informativo1)
        val btn_Mais=findViewById<Button>(R.id.btn_mais)
        val btn_Menos=findViewById<Button>(R.id.btn_menos)
        val txt_QH=findViewById<TextView>(R.id.txt_Informativo2)
        val txt_Final=findViewById<TextView>(R.id.txt_Informativo3)
        val btn_final=findViewById<Button>(R.id.btn_finalresenha)

        var total=20.00
        var Quantidade=0
        var pedido_atual=0.00

        /**
         *Radio Buttons da comida (adicionais com preços pré-definidos)
         *
         */

        btn_Bacon.setOnClickListener {
            total+=5.00
        }
        btn_Picles.setOnClickListener {
            total+=7.00
        }
        btn_Queijo.setOnClickListener {
            total+=4.50
        }

        /*
        * Botões de mais e menos hamburguers
        * */
        btn_Mais.setOnClickListener {
            Quantidade+=1
            txt_QH.text=Quantidade.toString()
        }
        btn_Menos.setOnClickListener {
            if(Quantidade>0){
                Quantidade-=1
                txt_QH.text=Quantidade.toString()

            }
        }
        /*
        * Apresentação do valor final em R$
        * */
        txt_Final.text=total.toString()

        /*
        * Salvando pedido atual ( o último que foi feito)
        * */
        btn_final.setOnClickListener {
            pedido_atual=total*Quantidade
            txt_Titulo.text=pedido_atual.toString()
        }
    }

}