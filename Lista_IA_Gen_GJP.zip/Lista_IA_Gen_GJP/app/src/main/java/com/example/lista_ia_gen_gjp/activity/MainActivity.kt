package com.example.lista_ia_gen_gjp.activity 

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.lista_ia_gen_gjp.R
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var txtResposta: TextView
    private lateinit var edtPergunta: EditText
    private lateinit var btnEnviar: Button

    private val apiKey = "AIzaSyCZYQ6yiBAiLh3H154XnEF_o0G_1mQQgfQM"

    private val modeloGemini = "gemini-2.5-flash-lite"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtResposta = findViewById(R.id.txtResposta)
        edtPergunta = findViewById(R.id.edtPergunta)
        btnEnviar = findViewById(R.id.btnEnviar)

        btnEnviar.setOnClickListener {
            val pergunta = edtPergunta.text.toString().trim()

            if (pergunta.isEmpty()) {
                Toast.makeText(this, "Digite algo primeiro.", Toast.LENGTH_SHORT).show()
            } else {
                enviarParaGemini(pergunta)
            }
        }
    }

    private fun enviarParaGemini(pergunta: String) {
        bloquearTela(true)

        txtResposta.text = "Pensando..."

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modeloGemini:generateContent"

        val prompt = """
            Você é um assistente didático, claro e objetivo.
            Responda sempre em português do Brasil.
            Explique de forma simples e organizada.
            De acordo com a ideia de projeto fornecida pelo usuário gere:
            documentação técnica, incluindo ob-
            jetivo, funcionalidades, tecnologias, requisitos, banco de
            dados e README para GitHub.
            Pergunta do usuário:
            $pergunta
        """.trimIndent()

        val corpoJson = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
        }.toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .addHeader("x-goog-api-key", apiKey)
            .post(corpoJson.toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).enqueue(object : Callback {

            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    bloquearTela(false)
                    txtResposta.text = "Erro de conexão: ${e.message}"
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val respostaBruta = it.body?.string().orEmpty()

                    if (!it.isSuccessful) {
                        runOnUiThread {
                            bloquearTela(false)
                            txtResposta.text = tratarErro(it.code, respostaBruta)
                        }
                        return
                    }

                    try {
                        val respostaDaIa = extrairTexto(respostaBruta)

                        runOnUiThread {
                            bloquearTela(false)
                            txtResposta.text = respostaDaIa
                        }

                    } catch (e: Exception) {
                        runOnUiThread {
                            bloquearTela(false)
                            txtResposta.text =
                                "Erro ao interpretar resposta da IA:\n${e.message}\n\n$respostaBruta"
                        }
                    }
                }
            }
        })
    }

    private fun extrairTexto(respostaBruta: String): String {
        val json = JSONObject(respostaBruta)

        return json
            .getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")
            .getJSONObject(0)
            .getString("text")
    }

    private fun tratarErro(codigo: Int, corpoErro: String): String {
        return when (codigo) {
            400 -> "Erro 400: requisição inválida.\n\n$corpoErro"
            401 -> "Erro 401: API Key inválida ou não autorizada.\n\n$corpoErro"
            403 -> "Erro 403: sem permissão para usar a API Gemini.\n\n$corpoErro"
            404 -> "Erro 404: modelo não encontrado. Verifique o nome do modelo.\n\n$corpoErro"
            429 -> "Erro 429: limite de uso atingido. Tente novamente mais tarde.\n\n$corpoErro"
            500 -> "Erro 500: erro interno no servidor.\n\n$corpoErro"
            503 -> "Erro 503: modelo ocupado ou indisponível.\n\n$corpoErro"
            else -> "Erro $codigo ao chamar a API Gemini.\n\n$corpoErro"
        }
    }

    private fun bloquearTela(bloquear: Boolean) {
        btnEnviar.isEnabled = !bloquear
        edtPergunta.isEnabled = !bloquear

        btnEnviar.text = if (bloquear) {
            "AGUARDE..."
        } else {
            "ENVIAR"
        }
    }
}