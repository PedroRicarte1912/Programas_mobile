package com.example.sistema_controlefinacas_prg_3f

import BancoHelper
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MapearComidaActivity : AppCompatActivity() {
    private lateinit var txt_mensagem12: TextView
    private lateinit var edt_gastocomida: EditText
    private lateinit var btn_confirmacomida: Button
    private lateinit var bancoHelper: BancoHelper
    private var idUsuario: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mapearcomida)
        txt_mensagem12 = findViewById<TextView>(R.id.txt_mensagem12)
        edt_gastocomida = findViewById<EditText>(R.id.edt_gastocomida)
        btn_confirmacomida = findViewById<Button>(R.id.btn_confirmacomida)
        bancoHelper = BancoHelper(this)
        idUsuario = intent.getIntExtra("ID_USUARIO", -1)

        btn_confirmacomida.setOnClickListener {
            cadastraComida()
        }
    }

    private fun cadastraComida() {
        val gasto = edt_gastocomida.text.toString().trim()

        // Validação 1: campo vazio (antes do toDouble para evitar crash)
        if (gasto.isBlank()) {
            Toast.makeText(this, "Preencha os campos solicitados", Toast.LENGTH_SHORT).show()
            return
        }

        val gasto2 = gasto.toDouble()

        // Validação 2: valor inválido
        if (gasto2 <= 0.00) {
            Toast.makeText(this, "Insira um gasto válido (maior que zero)", Toast.LENGTH_SHORT).show()
            return
        }

        // Validação 3: usuário não identificado
        if (idUsuario == -1) {
            Toast.makeText(this, "Erro: usuário não identificado", Toast.LENGTH_SHORT).show()
            return
        }
        // Atualiza o registro existente somando o novo valor, ou cria um novo
        val resultado = bancoHelper.salvarOuAtualizarGasto(
            idUsuario = idUsuario,
            contas = gasto2
            // comida, lazer e parcelas ficam 0.0 por padrão
        )
        if (resultado) {
            Toast.makeText(this, "Gasto cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
            val tela_mapear = Intent(this, MapearActivity::class.java)
            tela_mapear.putExtra("ID_USUARIO", idUsuario)
            startActivity(tela_mapear)
        } else {
            Toast.makeText(this, "Erro ao salvar gasto, tente novamente", Toast.LENGTH_SHORT).show()
        }
    }
}