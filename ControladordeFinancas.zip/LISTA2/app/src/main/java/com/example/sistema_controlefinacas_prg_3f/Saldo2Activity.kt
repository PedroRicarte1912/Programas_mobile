package com.example.sistema_controlefinacas_prg_3f

import BancoHelper
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Saldo2Activity : AppCompatActivity() {
    var tela_atual = "saldo2"
    private lateinit var txt_mensagem10: TextView
    private lateinit var edt_saldo: EditText
    private lateinit var btn_confirmasaldo: Button
    private lateinit var bancoHelper: BancoHelper
    private var idUsuario: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saldo2)
        txt_mensagem10 = findViewById<TextView>(R.id.txt_mensagem10)
        edt_saldo = findViewById<EditText>(R.id.edt_saldo)
        btn_confirmasaldo = findViewById<Button>(R.id.btn_confirmasaldo)
        bancoHelper = BancoHelper(this)

        // Recebe o id do usuário logado enviado pela tela anterior
        idUsuario = intent.getIntExtra("ID_USUARIO", -1)

        btn_confirmasaldo.setOnClickListener {
            cadastraSaldo()
        }
    }

    private fun cadastraSaldo() {
        val saldo_novo = edt_saldo.text.toString().trim()

        // Validação 1: campo vazio (feita ANTES de converter para Double)
        if (saldo_novo.isBlank()) {
            edt_saldo.error="Insira um valor de saldo antes de confirmar!"
            edt_saldo.requestFocus()
            return // interrompe aqui, evita o crash do toDouble()
        }

        val saldo_novo2 = saldo_novo.toDouble()

        // Validação 2: saldo inválido
        if (saldo_novo2 <= 0.00) {
            edt_saldo.error="Insira um saldo positivo e superior à 0.00!"
            edt_saldo.requestFocus()
            return
        }

        // Validação 3: id do usuário não recebido
        if (idUsuario == -1) {
            Toast.makeText(this, "Erro: usuário não identificado", Toast.LENGTH_SHORT).show()
            return
        }

        // Salva no banco
        val resultado = bancoHelper.salvarSaldo(idUsuario, saldo_novo2)

        if (resultado != -1L) {
            Toast.makeText(this, "Saldo cadastrado com sucesso!", Toast.LENGTH_SHORT).show()

            if (tela_atual == "saldo2") {
                val tela_financas1dnv = Intent(this, TelaFinancas1Activity::class.java)
                tela_financas1dnv.putExtra("ID_USUARIO", idUsuario) // continua passando o id
                startActivity(tela_financas1dnv)
            }
        } else {
            Toast.makeText(this, "Erro ao salvar saldo, tente novamente", Toast.LENGTH_SHORT).show()
        }
    }
}