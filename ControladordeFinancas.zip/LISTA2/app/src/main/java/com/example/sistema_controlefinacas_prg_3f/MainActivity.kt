package com.example.sistema_controlefinacas_prg_3f
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
class MainActivity : AppCompatActivity() {
    private lateinit var txt_mensagem1: TextView
    private lateinit var txt_mensagem2: TextView
    private lateinit var btn_login: Button
    private lateinit var btn_criaconta: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        txt_mensagem1=findViewById<TextView>(R.id.txt_mensagem1)
        txt_mensagem2=findViewById<TextView>(R.id.txt_mensagem2)
        btn_login=findViewById<Button>(R.id.btn_login)
        btn_criaconta=findViewById<Button>(R.id.btn_criaconta)

        // Chama as telas respectivas dos botões "btn_criaconta" e "btn_login"
        btn_criaconta.setOnClickListener {
            val tela_criarconta= Intent(this, CriaContaActivity::class.java)
            startActivity(tela_criarconta)
        }
        btn_login.setOnClickListener{
            val tela_login=Intent(this, LoginActivity::class.java)
            startActivity(tela_login)
        }
    }
}