package com.example.sistema_controlefinacas_prg_3f

import BancoHelper
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class TelaFinancas1Activity: AppCompatActivity() {
        private lateinit var txt_mensagem8: TextView
        private lateinit var btn_saldo: Button
        private lateinit var btn_mapear: Button
        private lateinit var bancoHelper: BancoHelper
        var i=0

        override fun onCreate(savedInstanceState: Bundle?){
            super.onCreate(savedInstanceState)
                setContentView(R.layout.activity_telafinancas1)
                txt_mensagem8=findViewById<TextView>(R.id.txt_mensagem8)
                btn_saldo=findViewById<Button>(R.id.btn_saldo)
                btn_mapear=findViewById<Button>(R.id.btn_mapear)
                bancoHelper= BancoHelper(this)

                btn_saldo.setOnClickListener {
                    i=1
                    val tela_saldo= Intent(this, SaldoActivity::class.java)
                    startActivity(tela_saldo)
                    finish()
                }
                btn_mapear.setOnClickListener {
                    if(i==0){
                        Toast.makeText(this,"Preencha seu saldo antes de começar a mapear!",Toast.LENGTH_SHORT).show()
                    }else{
                        val tela_mapear=Intent(this, MapearActivity::class.java)
                        startActivity(tela_mapear)
                        finish()
                    }
                }
        }
}