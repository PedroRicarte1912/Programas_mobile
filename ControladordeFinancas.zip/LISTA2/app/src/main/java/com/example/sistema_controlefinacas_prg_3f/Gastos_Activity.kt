package com.example.sistema_controlefinacas_prg_3f

import BancoHelper
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Gastos_Activity : AppCompatActivity() {

    private lateinit var txt_comida_gasto: TextView
    private lateinit var txt_lazer_gasto: TextView
    private lateinit var txt_personal_gasto: TextView
    private lateinit var txt_contas_gasto: TextView
    private lateinit var txt_parcelas_gasto: TextView
    private lateinit var txt_mensagemgasto: TextView
    private lateinit var btn_exportPDF: Button
    private lateinit var txt_saldofinal: TextView
    private lateinit var bancoHelper: BancoHelper
    private var idUsuario: Int = -1

    // Guarda os valores calculados para usar no PDF
    private var dadosParaPDF = mapOf<String, Any>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visualizargastos)

        txt_mensagemgasto = findViewById(R.id.txt_mensagemgasto)
        txt_lazer_gasto = findViewById(R.id.txt_lazer_gasto)
        txt_comida_gasto = findViewById(R.id.txt_comida_gasto)
        txt_personal_gasto = findViewById(R.id.txt_personal_gasto)
        txt_parcelas_gasto = findViewById(R.id.txt_parcelas_gasto)
        txt_contas_gasto = findViewById(R.id.txt_contas_gasto)
        txt_saldofinal = findViewById(R.id.txt_saldo_final)
        btn_exportPDF = findViewById(R.id.btn_exportPDF)

        bancoHelper = BancoHelper(this)
        idUsuario = intent.getIntExtra("ID_USUARIO", -1)

        exibirValores()

        btn_exportPDF.setOnClickListener {
            gerarEBaixarPDF()
        }
    }

    private fun exibirValores() {
        if (idUsuario == -1) {
            txt_mensagemgasto.text = "Erro ao identificar usuário"
            return
        }

        val saldo = bancoHelper.buscarSaldo(idUsuario)
        val gastos = bancoHelper.buscarGastos(idUsuario)
        val totalPersonalizados = bancoHelper.buscarTotalGastosPersonalizados(idUsuario)
        val dadosUsuario = bancoHelper.buscarDadosUsuario(idUsuario)

        val comida = gastos["comida"] ?: 0.0
        val lazer = gastos["lazer"] ?: 0.0
        val contas = gastos["contas"] ?: 0.0
        val parcelas = gastos["parcelas"] ?: 0.0

        txt_comida_gasto.text = "Comida: R$ %.2f".format(comida)
        txt_lazer_gasto.text = "Lazer: R$ %.2f".format(lazer)
        txt_contas_gasto.text = "Contas: R$ %.2f".format(contas)
        txt_parcelas_gasto.text = "Parcelas: R$ %.2f".format(parcelas)
        txt_personal_gasto.text = "Personalizados: R$ %.2f".format(totalPersonalizados)

        val totalGastos = comida + lazer + contas + parcelas + totalPersonalizados
        val saldoFinal = saldo - totalGastos

        txt_saldofinal.text = "Saldo final: R$ %.2f".format(saldoFinal)

        // Salva os dados para o PDF
        dadosParaPDF = mapOf(
            "nome" to (dadosUsuario["nome"] ?: ""),
            "email" to (dadosUsuario["email"] ?: ""),
            "saldo" to saldo,
            "comida" to comida,
            "lazer" to lazer,
            "contas" to contas,
            "parcelas" to parcelas,
            "personalizados" to totalPersonalizados,
            "totalGastos" to totalGastos,
            "saldoFinal" to saldoFinal
        )
    }

    private fun gerarEBaixarPDF() {
        if (idUsuario == -1) {
            Toast.makeText(this, "Erro: usuário não identificado", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            // --- Monta dados ---
            val nome = dadosParaPDF["nome"] as? String ?: ""
            val email = dadosParaPDF["email"] as? String ?: ""
            val saldo = dadosParaPDF["saldo"] as? Double ?: 0.0
            val comida = dadosParaPDF["comida"] as? Double ?: 0.0
            val lazer = dadosParaPDF["lazer"] as? Double ?: 0.0
            val contas = dadosParaPDF["contas"] as? Double ?: 0.0
            val parcelas = dadosParaPDF["parcelas"] as? Double ?: 0.0
            val personalizados = dadosParaPDF["personalizados"] as? Double ?: 0.0
            val totalGastos = dadosParaPDF["totalGastos"] as? Double ?: 0.0
            val saldoFinal = dadosParaPDF["saldoFinal"] as? Double ?: 0.0
            val gastosPersonalizadosLista = bancoHelper.buscarGastosPersonalizadosLista(idUsuario)

            // --- Cria documento PDF ---
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4
            val page = pdfDocument.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            // --- Configuração de Paints ---
            val paintTitulo = Paint().apply {
                color = Color.parseColor("#1565C0")
                textSize = 22f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val paintSecao = Paint().apply {
                color = Color.parseColor("#1976D2")
                textSize = 15f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val paintLabel = Paint().apply {
                color = Color.DKGRAY
                textSize = 13f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val paintValor = Paint().apply {
                color = Color.BLACK
                textSize = 13f
                isAntiAlias = true
            }
            val paintLinha = Paint().apply {
                color = Color.parseColor("#BBDEFB")
                strokeWidth = 1f
            }
            val paintSaldoPositivo = Paint().apply {
                color = Color.parseColor("#2E7D32")
                textSize = 15f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val paintSaldoNegativo = Paint().apply {
                color = Color.parseColor("#C62828")
                textSize = 15f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val paintRodape = Paint().apply {
                color = Color.GRAY
                textSize = 10f
                isAntiAlias = true
            }

            // --- Cabeçalho ---
            val paintCabecalhoFundo = Paint().apply {
                color = Color.parseColor("#1565C0")
                style = Paint.Style.FILL
            }
            canvas.drawRect(0f, 0f, 595f, 70f, paintCabecalhoFundo)

            val paintTituloHeader = Paint().apply {
                color = Color.WHITE
                textSize = 22f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.drawText("Relatório Financeiro", 30f, 45f, paintTituloHeader)

            // Data no cabeçalho
            val paintDataHeader = Paint().apply {
                color = Color.parseColor("#BBDEFB")
                textSize = 11f
                isAntiAlias = true
            }
            val dataHoje = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date())
            canvas.drawText("Gerado em: $dataHoje", 400f, 45f, paintDataHeader)

            // --- Posição Y corrente ---
            var y = 100f
            val margem = 30f
            val largura = 535f

            // --- Seção: Dados do Usuário ---
            canvas.drawText("Dados do Usuário", margem, y, paintSecao)
            y += 6f
            canvas.drawLine(margem, y, margem + largura, y, paintLinha)
            y += 18f

            canvas.drawText("Nome:", margem, y, paintLabel)
            canvas.drawText(nome, 150f, y, paintValor)
            y += 22f

            canvas.drawText("E-mail:", margem, y, paintLabel)
            canvas.drawText(email, 150f, y, paintValor)
            y += 22f

            canvas.drawText("Saldo cadastrado:", margem, y, paintLabel)
            canvas.drawText("R$ %.2f".format(saldo), 150f, y, paintValor)
            y += 30f

            // --- Seção: Gastos Fixos ---
            canvas.drawText("Gastos Fixos", margem, y, paintSecao)
            y += 6f
            canvas.drawLine(margem, y, margem + largura, y, paintLinha)
            y += 18f

            val gastosFixos = listOf(
                "Comida" to comida,
                "Lazer" to lazer,
                "Contas" to contas,
                "Parcelas" to parcelas
            )

            for ((label, valor) in gastosFixos) {
                canvas.drawText(label, margem + 10f, y, paintLabel)
                canvas.drawText("R$ %.2f".format(valor), 300f, y, paintValor)
                y += 22f
            }
            y += 8f

            // --- Seção: Gastos Personalizados ---
            canvas.drawText("Gastos Personalizados", margem, y, paintSecao)
            y += 6f
            canvas.drawLine(margem, y, margem + largura, y, paintLinha)
            y += 18f

            if (gastosPersonalizadosLista.isEmpty()) {
                canvas.drawText("Nenhum gasto personalizado cadastrado.", margem + 10f, y, paintValor)
                y += 22f
            } else {
                for ((nomeGasto, valorGasto) in gastosPersonalizadosLista) {
                    canvas.drawText(nomeGasto, margem + 10f, y, paintLabel)
                    canvas.drawText("R$ %.2f".format(valorGasto), 300f, y, paintValor)
                    y += 22f
                }
            }
            y += 8f

            // --- Seção: Resumo Final ---
            canvas.drawText("Resumo", margem, y, paintSecao)
            y += 6f
            canvas.drawLine(margem, y, margem + largura, y, paintLinha)
            y += 18f

            canvas.drawText("Total de gastos:", margem + 10f, y, paintLabel)
            canvas.drawText("R$ %.2f".format(totalGastos), 300f, y, paintValor)
            y += 28f

            // Caixa de destaque para saldo final
            val paintCaixaSaldo = Paint().apply {
                color = if (saldoFinal >= 0) Color.parseColor("#E8F5E9") else Color.parseColor("#FFEBEE")
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(margem, y - 18f, margem + largura, y + 12f, 8f, 8f, paintCaixaSaldo)

            canvas.drawText("Saldo Final:", margem + 10f, y, paintLabel)
            val paintFinal = if (saldoFinal >= 0) paintSaldoPositivo else paintSaldoNegativo
            canvas.drawText("R$ %.2f".format(saldoFinal), 300f, y, paintFinal)
            y += 30f

            // --- Rodapé ---
            canvas.drawLine(margem, 810f, margem + largura, 810f, paintLinha)
            canvas.drawText("Gerado pelo app Controle Financeiro", margem, 828f, paintRodape)

            // --- Finaliza página ---
            pdfDocument.finishPage(page)

            // --- Salva o arquivo ---
            val nomeArquivo = "relatorio_financeiro_${
                SimpleDateFormat("ddMMyyyy_HHmm", Locale("pt", "BR")).format(Date())
            }.pdf"

            val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            if (dir != null && !dir.exists()) dir.mkdirs()

            val arquivo = File(dir, nomeArquivo)
            pdfDocument.writeTo(FileOutputStream(arquivo))
            pdfDocument.close()

            // --- Abre o PDF com visualizador do celular ---
            val uri = FileProvider.getUriForFile(
                this,
                "${packageName}.provider",
                arquivo
            )

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
            }

            startActivity(Intent.createChooser(intent, "Abrir PDF com..."))
            Toast.makeText(this, "PDF salvo em: ${arquivo.absolutePath}", Toast.LENGTH_LONG).show()

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Erro ao gerar PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}