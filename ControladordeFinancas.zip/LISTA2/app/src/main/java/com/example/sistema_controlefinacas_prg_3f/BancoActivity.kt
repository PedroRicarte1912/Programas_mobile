import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BancoHelper(context: Context): SQLiteOpenHelper(context, "bancoapp.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE usuario(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nome TEXT NOT NULL, " +
                "email TEXT NOT NULL, " +
                "senha TEXT NOT NULL)")

        db.execSQL("CREATE TABLE valoresXusuarios(" +
                "saldo TEXT NOT NULL, " +
                "id_X INTEGER, " +
                "FOREIGN KEY (id_X) REFERENCES usuario(id) ON DELETE CASCADE ON UPDATE CASCADE)")

        db.execSQL("CREATE TABLE Gastos_user(" +
                "id_gastos INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "gasto_comida REAL, " +
                "gasto_lazer REAL, " +
                "gasto_contas REAL, " +
                "gasto_parcelas REAL, " +
                "id_user_fk INTEGER, " +
                "FOREIGN KEY (id_user_fk) REFERENCES usuario(id) ON DELETE CASCADE ON UPDATE CASCADE)")

        // NOVA TABELA para gastos personalizados
        db.execSQL("CREATE TABLE Gastos_personalizados(" +
                "id_personalizado INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nome_gasto TEXT NOT NULL, " +
                "valor_gasto REAL NOT NULL, " +
                "id_user_fk INTEGER, " +
                "FOREIGN KEY (id_user_fk) REFERENCES usuario(id) ON DELETE CASCADE ON UPDATE CASCADE)")
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
        db.execSQL("DROP TABLE IF EXISTS valoresXusuarios")
        db.execSQL("DROP TABLE IF EXISTS Gastos_personalizados") // nova tabela no drop
        db.execSQL("DROP TABLE IF EXISTS Gastos_user")
        db.execSQL("DROP TABLE IF EXISTS usuario")
        onCreate(db)
    }

    fun inserirUsuario(nome: String, email: String, senha: String): Long {
        val db = this.writableDatabase
        val valores = ContentValues().apply {
            put("nome", nome)
            put("email", email)
            put("senha", senha)
        }

        val idGerado = db.insert("usuario", null, valores)

        db.close()
        return idGerado
    }
    fun verificarUsuario(email: String, senha: String): Int {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "SELECT id FROM usuario WHERE email = ? AND senha = ?",
            arrayOf(email, senha)
        )

        var idEncontrado = -1

        if (cursor.moveToFirst()) {
            idEncontrado = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
        }

        cursor.close()
        db.close()
        return idEncontrado // retorna o id do usuário, ou -1 se não encontrar
    }
    fun salvarSaldo(idUsuario: Int, saldo: Double): Long {
        val db = this.writableDatabase
        val valores = ContentValues().apply {
            put("id_X", idUsuario)
            put("saldo", saldo.toString())
        }

        val idGerado = db.insert("valoresXusuarios", null, valores)
        db.close()
        return idGerado // retorna -1 se falhou, ou o id da linha inserida
    }
    fun buscarSaldo(idUsuario: Int): Double {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "SELECT saldo FROM valoresXusuarios WHERE id_X = ? ORDER BY rowid DESC LIMIT 1",
            arrayOf(idUsuario.toString())
        )

        var saldo = 0.0

        if (cursor.moveToFirst()) {
            saldo = cursor.getString(cursor.getColumnIndexOrThrow("saldo")).toDouble()
        }

        cursor.close()
        db.close()
        return saldo // retorna 0.0 se nenhum saldo for encontrado
    }

    // Função de inserção de gastos atualizada para receber o ID do utilizador
    fun inserirGastos(idUsuario: Int, comida: Double, lazer: Double, contas: Double, parcelas: Double): Long {
        val db = writableDatabase
        val valores = ContentValues()

        valores.put("id_user_fk", idUsuario) // Vincula o gasto ao ID do usuário logado
        valores.put("gasto_comida", comida)
        valores.put("gasto_lazer", lazer)
        valores.put("gasto_contas", contas)
        valores.put("gasto_parcelas", parcelas)

        val idGerado= db.insert("Gastos_user", null, valores)
        db.close()
        return idGerado
    }

    fun salvarOuAtualizarGasto(
        idUsuario: Int,
        comida: Double = 0.0,
        lazer: Double = 0.0,
        contas: Double = 0.0,
        parcelas: Double = 0.0
    ): Boolean {
        val db = this.writableDatabase

        // Busca o registro mais recente do usuário
        val cursor = db.rawQuery(
            "SELECT id_gastos, gasto_comida, gasto_lazer, gasto_contas, gasto_parcelas " +
                    "FROM Gastos_user WHERE id_user_fk = ? ORDER BY id_gastos DESC LIMIT 1",
            arrayOf(idUsuario.toString())
        )

        return if (cursor.moveToFirst()) {
            // Já existe um registro: soma o novo valor ao existente
            val idGasto = cursor.getInt(cursor.getColumnIndexOrThrow("id_gastos"))
            val comidaAtual = cursor.getDouble(cursor.getColumnIndexOrThrow("gasto_comida"))
            val lazerAtual = cursor.getDouble(cursor.getColumnIndexOrThrow("gasto_lazer"))
            val contasAtual = cursor.getDouble(cursor.getColumnIndexOrThrow("gasto_contas"))
            val parcelasAtual = cursor.getDouble(cursor.getColumnIndexOrThrow("gasto_parcelas"))

            cursor.close()

            val valores = ContentValues().apply {
                put("gasto_comida", comidaAtual + comida)
                put("gasto_lazer", lazerAtual + lazer)
                put("gasto_contas", contasAtual + contas)
                put("gasto_parcelas", parcelasAtual + parcelas)
            }

            val linhasAfetadas = db.update(
                "Gastos_user", valores,
                "id_gastos = ?", arrayOf(idGasto.toString())
            )
            db.close()
            linhasAfetadas > 0 // true se atualizou com sucesso

        } else {
            // Não existe registro: cria um novo
            cursor.close()

            val valores = ContentValues().apply {
                put("id_user_fk", idUsuario)
                put("gasto_comida", comida)
                put("gasto_lazer", lazer)
                put("gasto_contas", contas)
                put("gasto_parcelas", parcelas)
            }

            val idGerado = db.insert("Gastos_user", null, valores)
            db.close()
            idGerado != -1L // true se inseriu com sucesso
        }
    }
    fun salvarGastoPersonalizado(idUsuario: Int, nome: String, valor: Double): Boolean {
        val db = this.writableDatabase
        val valores = ContentValues().apply {
            put("id_user_fk", idUsuario)
            put("nome_gasto", nome)
            put("valor_gasto", valor)
        }

        val idGerado = db.insert("Gastos_personalizados", null, valores)
        db.close()
        return idGerado != -1L
    }
    fun buscarGastos(idUsuario: Int): Map<String, Double> {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "SELECT gasto_comida, gasto_lazer, gasto_contas, gasto_parcelas " +
                    "FROM Gastos_user WHERE id_user_fk = ? ORDER BY id_gastos DESC LIMIT 1",
            arrayOf(idUsuario.toString())
        )

        val resultado = mutableMapOf(
            "comida" to 0.0,
            "lazer" to 0.0,
            "contas" to 0.0,
            "parcelas" to 0.0
        )

        if (cursor.moveToFirst()) {
            resultado["comida"] = cursor.getDouble(cursor.getColumnIndexOrThrow("gasto_comida"))
            resultado["lazer"] = cursor.getDouble(cursor.getColumnIndexOrThrow("gasto_lazer"))
            resultado["contas"] = cursor.getDouble(cursor.getColumnIndexOrThrow("gasto_contas"))
            resultado["parcelas"] = cursor.getDouble(cursor.getColumnIndexOrThrow("gasto_parcelas"))
        }

        cursor.close()
        db.close()
        return resultado
    }

    fun buscarTotalGastosPersonalizados(idUsuario: Int): Double {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "SELECT SUM(valor_gasto) AS total FROM Gastos_personalizados WHERE id_user_fk = ?",
            arrayOf(idUsuario.toString())
        )

        var total = 0.0
        if (cursor.moveToFirst()) {
            total = cursor.getDouble(cursor.getColumnIndexOrThrow("total"))
        }

        cursor.close()
        db.close()
        return total
    }
    fun buscarDadosUsuario(idUsuario: Int): Map<String, String> {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "SELECT nome, email FROM usuario WHERE id = ?",
            arrayOf(idUsuario.toString())
        )

        val dados = mutableMapOf("nome" to "", "email" to "")

        if (cursor.moveToFirst()) {
            dados["nome"] = cursor.getString(cursor.getColumnIndexOrThrow("nome"))
            dados["email"] = cursor.getString(cursor.getColumnIndexOrThrow("email"))
        }

        cursor.close()
        db.close()
        return dados
    }

    fun buscarGastosPersonalizadosLista(idUsuario: Int): List<Pair<String, Double>> {
        val db = this.readableDatabase
        val cursor = db.rawQuery(
            "SELECT nome_gasto, valor_gasto FROM Gastos_personalizados WHERE id_user_fk = ?",
            arrayOf(idUsuario.toString())
        )

        val lista = mutableListOf<Pair<String, Double>>()

        while (cursor.moveToNext()) {
            val nome = cursor.getString(cursor.getColumnIndexOrThrow("nome_gasto"))
            val valor = cursor.getDouble(cursor.getColumnIndexOrThrow("valor_gasto"))
            lista.add(Pair(nome, valor))
        }

        cursor.close()
        db.close()
        return lista
    }

}