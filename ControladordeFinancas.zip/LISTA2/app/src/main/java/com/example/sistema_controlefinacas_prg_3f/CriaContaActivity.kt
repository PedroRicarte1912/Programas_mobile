package com.example.sistema_controlefinacas_prg_3f
import BancoHelper
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.util.Patterns
import android.widget.Toast
//classe do xml e seus itens
class CriaContaActivity: AppCompatActivity() {
    private lateinit var txt_mensagem3: TextView
    private lateinit var txt_mensagem4: TextView
    private lateinit var edt_nomecc: EditText
    private lateinit var edt_emailcc: EditText
    private lateinit var edt_senhacc: EditText
    private lateinit var edt_confirmasenhacc: EditText
    private lateinit var btn_confirmacriacao: Button
    private lateinit var bancoHelper: BancoHelper

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_criarconta)
        txt_mensagem3=findViewById<TextView>(R.id.txt_mensagem3)
        txt_mensagem4=findViewById<TextView>(R.id.txt_mensagem4)
        edt_nomecc=findViewById<EditText>(R.id.edt_nomecc)
        edt_emailcc=findViewById<EditText>(R.id.edt_emailcc)
        edt_senhacc=findViewById<EditText>(R.id.edt_senhacc)
        edt_confirmasenhacc=findViewById<EditText>(R.id.edt_confirmasenhacc)
        btn_confirmacriacao=findViewById<Button>(R.id.btn_confirmacriacao)
        bancoHelper= BancoHelper(this)
        btn_confirmacriacao.setOnClickListener {
            criaConta()
        }
    }
    // função privada criaConta(); Realiza as validações necessárias sobre as informações solicitadas
    // em seguida insere no banco de dados e passa pra próxima tela
    private fun criaConta() {
        var dados=true
        val nome_user = edt_nomecc.text.toString().trim()
        val email_user = edt_emailcc.text.toString().trim()
        val senha_user = edt_senhacc.text.toString().trim()
        val confsenha_user = edt_confirmasenhacc.text.toString().trim()
        if (nome_user.isBlank()) {
            edt_nomecc.error = "Insira um nome antes de continuar!"
            edt_nomecc.requestFocus()
            dados=false
            return
        }
        if (email_user.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(email_user).matches()){
            edt_emailcc.error = "Insira um e-mail válido antes de continuar!"
            edt_emailcc.requestFocus()
            dados=false
            return
        }
        if(senha_user.length<8){
            edt_senhacc.error="Insira uma senha de no mínimo 8 caracteres"
            edt_senhacc.requestFocus()
            dados=false
            return
        }
        if(senha_user!=confsenha_user){
            edt_confirmasenhacc.error="As senhas não coincidem"
            edt_confirmasenhacc.requestFocus()
            dados=false
            return
        }
        if(dados){
            val insercao=bancoHelper.inserirUsuario(nome_user,email_user,senha_user)
            if(insercao!=-1L){
                Toast.makeText(this,"Usuário salvo com sucesso",Toast.LENGTH_SHORT).show()
                val tela_financas1= Intent(this, TelaFinancas1Activity::class.java)
                startActivity(tela_financas1)
                finish()
            }else{
                Toast.makeText(this,"Erro ao cadastrar usuário, verifique todos os campos",Toast.LENGTH_SHORT).show()
            }
        }else{
            Toast.makeText(this,"Erro ao cadastrar usuário, verifique todos os campos",Toast.LENGTH_SHORT).show()
        }
    }
}
