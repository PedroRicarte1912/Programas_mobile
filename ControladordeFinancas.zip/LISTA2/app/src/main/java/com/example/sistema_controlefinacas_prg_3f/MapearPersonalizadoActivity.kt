package com.example.sistema_controlefinacas_prg_3f

import BancoHelper
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MapearPersonalizadoActivity : AppCompatActivity() {
    private lateinit var txt_mensagem16: TextView
    private lateinit var edt_nomePersonalizado: EditText
    private lateinit var edt_gastoPersonalizado: EditText
    private lateinit var btn_confirmaPersonalizado: Button
    private lateinit var bancoHelper: BancoHelper
    private var idUsuario: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mapearpersonalizado)
        txt_mensagem16 = findViewById(R.id.txt_mensagem16)
        edt_nomePersonalizado = findViewById(R.id.edt_nomePersonalizado)
        edt_gastoPersonalizado = findViewById(R.id.edt_gastoPersonalizado)
        btn_confirmaPersonalizado = findViewById(R.id.btn_confirmaPersonalizado)
        bancoHelper = BancoHelper(this)
        idUsuario = intent.getIntExtra("ID_USUARIO", -1)

        btn_confirmaPersonalizado.setOnClickListener {
            cadastraGasto()
        }
    }

    private fun cadastraGasto() {
        val nome = edt_nomePersonalizado.text.toString().trim()
        val gasto = edt_gastoPersonalizado.text.toString().trim()

        // Validação 1: campos vazios — ANTES do toDouble
        if (nome.isBlank()) {
            edt_nomePersonalizado.error = "Dê um nome para o gasto"
            return
        }
        if (gasto.isBlank()) {
            edt_gastoPersonalizado.error = "Preencha o valor do gasto"
            return
        }

        val gasto2 = gasto.toDouble()

        // Validação 2: valor inválido
        if (gasto2 <= 0.00) {
            edt_gastoPersonalizado.error = "Insira um valor maior que zero"
            return
        }

        // Validação 3: usuário não identificado
        if (idUsuario == -1) {
            Toast.makeText(this, "Erro: usuário não identificado", Toast.LENGTH_SHORT).show()
            return
        }

        val resultado = bancoHelper.salvarGastoPersonalizado(
            idUsuario = idUsuario,
            nome = nome,
            valor = gasto2
        )

        if (resultado) {
            Toast.makeText(this, "Gasto '$nome' cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
            val tela_mapear = Intent(this, MapearActivity::class.java)
            tela_mapear.putExtra("ID_USUARIO", idUsuario)
            startActivity(tela_mapear)
        } else {
            Toast.makeText(this, "Erro ao salvar gasto, tente novamente", Toast.LENGTH_SHORT).show()
        }
    }
}