package com.example.sistema_controlefinacas_prg_3f

import BancoHelper
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SaldoActivity: AppCompatActivity() {
    private lateinit var txt_mensagem9: TextView
    private lateinit var btn_semanal: Button
    private lateinit var btn_mensal: Button
    private lateinit var btn_anual: Button
    private lateinit var bancoHelper: BancoHelper
    private var idUsuario: Int = -1

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_saldo)
            txt_mensagem9=findViewById<TextView>(R.id.txt_mensagem9)
            btn_semanal=findViewById<Button>(R.id.btn_semanal)
            btn_mensal=findViewById<Button>(R.id.btn_mensal)
            btn_anual=findViewById<Button>(R.id.btn_anual)
            bancoHelper = BancoHelper(this)
            idUsuario = intent.getIntExtra("ID_USUARIO", -1)


            btn_semanal.setOnClickListener {
                val tela_saldo2= Intent(this, Saldo2Activity::class.java)
                startActivity(tela_saldo2)
            }
            btn_mensal.setOnClickListener {
                val tela_saldo2= Intent(this, Saldo2Activity::class.java)
                startActivity(tela_saldo2)
            }
            btn_anual.setOnClickListener {
                val tela_saldo2= Intent(this, Saldo2Activity::class.java)
                startActivity(tela_saldo2)
            }
    }
}