package com.example.sistema_controlefinacas_prg_3f

import BancoHelper
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {
    private lateinit var txt_mensagem5: TextView
    private lateinit var edt_emaillogin: EditText
    private lateinit var edt_senhalogin: EditText
    private lateinit var btn_fazerlogin: Button
    private lateinit var bancoHelper: BancoHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        txt_mensagem5 = findViewById<TextView>(R.id.txt_mensagem5)
        edt_emaillogin = findViewById<EditText>(R.id.edt_emaillogin)
        edt_senhalogin = findViewById<EditText>(R.id.edt_senhalogin)
        btn_fazerlogin = findViewById<Button>(R.id.btn_fazerlogin)
        bancoHelper = BancoHelper(this)

        btn_fazerlogin.setOnClickListener {
            realizarLogin()
        }
    }
    //Função privada realizarLogin(); Realiza as validações sobre email e senha
    // verifica se está presente no banco de dados e passa para próxima tela
    private fun realizarLogin() {
        val email = edt_emaillogin.text.toString().trim()
        val senha = edt_senhalogin.text.toString()

        // Validações básicas antes de consultar o banco
        if (email.isBlank()) {
            edt_emaillogin.error = "Digite seu e-mail"
            edt_emaillogin.requestFocus()
            return
        }
        if (senha.isBlank()) {
            edt_senhalogin.error = "Digite sua senha"
            edt_senhalogin.requestFocus()
            return
        }

        val idUsuario = bancoHelper.verificarUsuario(email, senha)

        if (idUsuario != -1) {
            Toast.makeText(this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show()
            val tela_financas1 = Intent(this, TelaFinancas1Activity::class.java)
            tela_financas1.putExtra("ID_USUARIO", idUsuario)// passa o id do user pra próxima tela
            startActivity(tela_financas1)
            finish() // impede de voltar para a tela de login com o botão "voltar"
        } else {
            Toast.makeText(this, "E-mail ou senha incorretos", Toast.LENGTH_SHORT).show()
        }
    }
}