package com.example.sistema_controlefinacas_prg_3f

import BancoHelper
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MapearActivity : AppCompatActivity() {
    private lateinit var txt_mensagem11: TextView
    private lateinit var btn_opcLazer: Button
    private lateinit var btn_opcParcelas: Button
    private lateinit var btn_opcComida: Button
    private lateinit var btn_opcContas: Button
    private lateinit var btn_personalizaarea: Button
    private lateinit var btn_visualizarGastos: Button
    private lateinit var bancoHelper: BancoHelper
    private var idUsuario: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mapear)
        txt_mensagem11 = findViewById<TextView>(R.id.txt_mensagem11)
        btn_opcContas = findViewById<Button>(R.id.btn_opcContas)
        btn_opcParcelas = findViewById<Button>(R.id.btn_opcParcelas)
        btn_opcComida = findViewById<Button>(R.id.btn_opcComida)
        btn_opcLazer = findViewById<Button>(R.id.btn_opcLazer)
        btn_personalizaarea = findViewById<Button>(R.id.btn_personalizaarea)
        btn_visualizarGastos = findViewById<Button>(R.id.btn_visualizarGastos)
        bancoHelper = BancoHelper(this)

        // Recebe o id do usuário logado
        idUsuario = intent.getIntExtra("ID_USUARIO", -1)

        exibirSaldo()

        btn_opcComida.setOnClickListener {
            val tela_comida = Intent(this, MapearComidaActivity::class.java)
            tela_comida.putExtra("ID_USUARIO", idUsuario) // continua passando o id
            startActivity(tela_comida)
            finish()
        }
        btn_opcLazer.setOnClickListener {
            val tela_lazer= Intent(this, MapearLazerActivity::class.java)
            tela_lazer.putExtra("ID_USUARIO", idUsuario) // continua passando o id
            startActivity(tela_lazer)
            finish()
        }
        btn_opcContas.setOnClickListener {
            val tela_contas = Intent(this, MapearContasActivity::class.java)
            tela_contas.putExtra("ID_USUARIO", idUsuario) // continua passando o id
            startActivity(tela_contas)
            finish()
        }
        btn_opcParcelas.setOnClickListener {
            val tela_parcelas = Intent(this, MapearParcelasActivity::class.java)
            tela_parcelas.putExtra("ID_USUARIO", idUsuario) // continua passando o id
            startActivity(tela_parcelas)
            finish()
        }
        btn_personalizaarea.setOnClickListener {
            val tela_personalizada=Intent(this, MapearPersonalizadoActivity::class.java)
            tela_personalizada.putExtra("ID_USUARIO",idUsuario)// continua passando o id
            startActivity(tela_personalizada)
            finish()
        }
        btn_visualizarGastos.setOnClickListener {
            val tela_gasto=Intent(this, Gastos_Activity::class.java)
            tela_gasto.putExtra("ID_USUARIO",idUsuario)// continua passando o id
            startActivity(tela_gasto)
            finish()
        }
    }

    private fun exibirSaldo() {
        if (idUsuario == -1) {
            txt_mensagem11.text = "Saldo: erro ao identificar usuário"
            return
        }

        val saldo = bancoHelper.buscarSaldo(idUsuario)

        // Formata o valor em reais: ex. "Saldo: R$ 1500,00"
        txt_mensagem11.text = "Saldo: R$ %.2f".format(saldo).replace(".", ",")
    }
}